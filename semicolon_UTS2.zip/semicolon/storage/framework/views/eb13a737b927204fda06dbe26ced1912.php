<nav class="navbar navbar-expand-lg">
    <div class="container-fluid py-3 px-xl-5">
        <a class="navbar-brand" href="/">SEMICOLON</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('test')); ?>">Test</a>
                </li>
            </ul>
            <div class="d-flex gap-2">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('form-regis', ['role' => 'client'])); ?>" class="btn btn-primary px-4 rounded-pill">
                        Daftar
                    </a>
                    <a href="<?php echo e(route('form-login', ['role' => 'client'])); ?>"
                        class="btn btn-outline-primary px-4 rounded-pill">
                        Masuk
                    </a>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-danger px-4 rounded-pill">
                            Keluar
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH Z:\xampp\htdocs\joki\web-6\semicolon\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>