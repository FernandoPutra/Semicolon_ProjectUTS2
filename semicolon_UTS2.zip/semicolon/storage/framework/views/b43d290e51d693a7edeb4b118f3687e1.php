<?php $__env->startSection('contents'); ?>
    <section id="soal" class="container">
        <form action="<?php echo e(route('test.post')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-7 col-md-6 col-12">
                    <div id="soal-carousel" class="carousel slide">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($idx == 0 ? 'active' : ''); ?>">
                                    <div class="container-fluid">
                                        <p><?php echo e($idx + 1); ?> / <?php echo e(count($soal)); ?></p>
                                        <h1 class="fw-bold">
                                            <?php echo e($item->isi_soal); ?>

                                        </h1>
                                        <p><b>Pilih salah satu jawaban:</b></p>
                                        <div class="d-flex flex-column align-items-start gap-3 fs-5">
                                            <div class="form-check">
                                                <input type="radio" name="jawaban-<?php echo e($idx + 1); ?>"
                                                    id="nol<?php echo e($idx + 1); ?>" class="form-check-input" value="0">
                                                <label class="form-check-label" for="nol<?php echo e($idx + 1); ?>">Tidak ada /
                                                    Tidak
                                                    pernah</label>
                                            </div>
                                            <div class="form-check">
                                                <input type="radio" name="jawaban-<?php echo e($idx + 1); ?>"
                                                    id="satu<?php echo e($idx + 1); ?>" class="form-check-input" value="1">
                                                <label class="form-check-label"
                                                    for="satu<?php echo e($idx + 1); ?>">Kadang-kadang</label>
                                            </div>
                                            <div class="form-check">
                                                <input type="radio" name="jawaban-<?php echo e($idx + 1); ?>"
                                                    id="dua<?php echo e($idx + 1); ?>" class="form-check-input" value="2">
                                                <label class="form-check-label" for="dua<?php echo e($idx + 1); ?>">Sering</label>
                                            </div>
                                            <div class="form-check">
                                                <input type="radio" name="jawaban-<?php echo e($idx + 1); ?>"
                                                    id="tiga<?php echo e($idx + 1); ?>" class="form-check-input" value="3">
                                                <label class="form-check-label" for="tiga<?php echo e($idx + 1); ?>">Sangat
                                                    Sesuai</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="d-flex align-items-cente justify-content-between mt-5">
                        <button class="btn btn-outline-dark" data-bs-target="#soal-carousel" data-bs-slide="prev"><i
                                class="bi bi-arrow-left-short"></i> Sebelumnya</button>
                        <button class="btn btn-dark" data-bs-target="#soal-carousel" data-bs-slide="next">Selanjutnya <i
                                class="bi bi-arrow-right-short"></i></button>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-secondary-subtle p-4 rounded-3">
                        <div class="row justify-content-evenly align-items-center gap-2">
                            <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-2 col-md-3 col-4 indicator">
                                    <button class="rounded-2 border border-secondary w-100 py-2" type="button"
                                        data-bs-target="#soal-carousel" data-bs-slide-to="<?php echo e($idx); ?>"
                                        aria-label="Pertanyaan Nomor <?php echo e($idx + 1); ?>"
                                        <?php echo e($idx == 0 ? 'aria-current="true"' : ''); ?>><?php echo e($idx + 1); ?></button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button class="mt-3 d-block w-100 btn btn-primary" type="submit">Kirim Tes</button>
                    </div>
                </div>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="resultModal" tabindex="-1" aria-labelledby="resultModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="resultModalLabel">Result</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <h2 class="h5">Test Complete</h2>
                    <h3 class="h3">Here Your Test Skor</h3>
                    <p class="text-primary h1 fw-bold" id="sumValue"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('add-js'); ?>
    <script type="text/javascript">
        const myCarouselElement = document.querySelector("#soal-carousel");

        const carousel = new bootstrap.Carousel(myCarouselElement, {
            ride: false,
            touch: false,
            wrap: false,
        });

        // const radioButtons = document.querySelectorAll('input[type="radio"]');
        // const indicators = document.querySelectorAll('.indicator button');

        // radioButtons.forEach((radioButton, index) => {
        //     let nomor = 1
        //     radioButton.addEventListener('click', () => {
        //         // Remove "active" class from all indicators
        //         indicators.forEach(indicator => {
        //             indicator.classList.remove('active');
        //         });

        //         // Add "active" class to the clicked indicator
        //         indicators[index].classList.add('active');
        //     });
        // });
    </script>
    <!-- Place this at the end of your view file, before the closing </body> tag -->
    <?php if(session('sum')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Show the modal
                var sumValue = '<?php echo e(session('sum')); ?>';
                var modal = new bootstrap.Modal(document.getElementById('resultModal'));
                document.getElementById('sumValue').textContent = sumValue;
                modal.show();
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\xampp\htdocs\joki\web-6\semicolon\resources\views/test.blade.php ENDPATH**/ ?>