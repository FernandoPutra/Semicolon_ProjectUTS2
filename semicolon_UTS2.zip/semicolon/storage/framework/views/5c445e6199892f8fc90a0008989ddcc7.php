<?php $__env->startSection('contents'); ?>
    <section id="register" class="container">
        <h3 class="text-primary">Selamat Datang Kembali!</h3>
        <hr class="mb-5" />
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('form-login.auth', ['role' => $role])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" name="email" id="email"
                        placeholder="Masukkan Email Anda" value="<?php echo e(old('email')); ?>" />
                </div>
            </div>
            <div class="row mb-3">
                <label for="password" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" name="password" id="password"
                        placeholder="Masukkan Password Anda" />
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Masuk</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\xampp\htdocs\joki\web-6\semicolon\resources\views/login.blade.php ENDPATH**/ ?>