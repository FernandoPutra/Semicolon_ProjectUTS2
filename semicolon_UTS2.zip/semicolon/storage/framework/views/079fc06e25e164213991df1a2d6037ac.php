<?php $__env->startSection('contents'); ?>
    <section id="register" class="container">
        <h3 class="text-primary">Isi Data Diri</h3>
        <hr class="mb-5" />
        <form action="<?php echo e(route('form-regis.store', ['role' => $role])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <label for="username" class="col-sm-2 col-form-label">Username</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="username" id="username"
                        placeholder="Masukkan Username Anda" />
                </div>
            </div>
            <div class="row mb-3">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" name="email" id="email"
                        placeholder="Masukkan Email Anda" autocomplete="true" />
                </div>
            </div>
            <div class="row mb-3">
                <label for="password" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" name="password" id="password"
                        placeholder="Masukkan Password Anda" />
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Buat Akun</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\xampp\htdocs\joki\web-6\semicolon\resources\views/register.blade.php ENDPATH**/ ?>