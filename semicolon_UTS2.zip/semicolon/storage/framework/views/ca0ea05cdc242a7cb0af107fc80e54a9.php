<footer>
    <div class="container-fluid py-5 text-center bg-light">
        <ul class="nav justify-content-center mb-3">
            <li class="nav-item">
                <a class="nav-link" href="#">Beranda</a>
            </li>
        </ul>
        <p><i class="bi bi-c-circle"></i> Copyright 2023</p>
    </div>
</footer>
<?php /**PATH Z:\xampp\htdocs\joki\web-6\semicolon\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>