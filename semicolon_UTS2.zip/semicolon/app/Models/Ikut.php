<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ikut extends Model
{
    // use HasFactory;

    protected $table = 'ikut';

    protected $guarded = ['id_tes'];
}
