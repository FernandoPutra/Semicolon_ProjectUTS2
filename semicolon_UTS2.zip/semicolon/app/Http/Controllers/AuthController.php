<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register($role)
    {
        return view('register', compact('role'));
    }

    public function store(Request $request)
    {
        $validate = $request->validate([
            'username' => 'required',
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $validate['password'] = Hash::make($request->password);

        $register = DB::table($request->role)->insert($validate);
        return $register ? redirect(route('form-login', ['role' => $request->role]))->with('success', 'Your register has been successfully, You can login now') : back()->with('error', 'Something wrong, please check your data and try again')->withInput($request->except('password'));
    }

    public function login($role)
    {
        return view('login', compact('role'));
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $attempt = Auth::attempt($credentials);
        if ($attempt) {
            $request->session()->regenerate();
            return redirect()->intended('/');
        }

        return back()->with('error', 'Invalid credentials')->withInput()->exceptInput('password');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }
}
