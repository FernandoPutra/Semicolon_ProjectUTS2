<?php

namespace App\Http\Controllers;

use App\Models\Ikut;
use App\Models\Soal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TestController extends Controller
{
    public function index()
    {
        $soal = Soal::all();
        return view('test', compact('soal'));
    }

    public function calculate(Request $request)
    {
        $inputValues = $request->all();
        $sum = 0;
        foreach ($inputValues as $key => $value) {
            if (strpos($key, 'jawaban-') === 0) {
                $sum += intval($value);
            }
        }

        Ikut::create([
            'id_pasien' => Auth::user()->id,
            'skor' => $sum,
        ]);

        return redirect()->back()->with('sum', $sum);
    }
}
