@extends('layouts.main')

@section('contents')
    <section id="register" class="container">
        <h3 class="text-primary">Selamat Datang Kembali!</h3>
        <hr class="mb-5" />
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <form action="{{ route('form-login.auth', ['role' => $role]) }}" method="POST">
            @csrf
            <div class="row mb-3">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" name="email" id="email"
                        placeholder="Masukkan Email Anda" value="{{ old('email') }}" />
                </div>
            </div>
            <div class="row mb-3">
                <label for="password" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" name="password" id="password"
                        placeholder="Masukkan Password Anda" />
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Masuk</button>
        </form>
    </section>
@endsection
