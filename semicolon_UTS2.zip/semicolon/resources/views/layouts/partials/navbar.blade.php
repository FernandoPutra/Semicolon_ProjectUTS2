<nav class="navbar navbar-expand-lg">
    <div class="container-fluid py-3 px-xl-5">
        <a class="navbar-brand" href="/">SEMICOLON</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('test') }}">Test</a>
                </li>
            </ul>
            <div class="d-flex gap-2">
                @guest
                    <a href="{{ route('form-regis', ['role' => 'client']) }}" class="btn btn-primary px-4 rounded-pill">
                        Daftar
                    </a>
                    <a href="{{ route('form-login', ['role' => 'client']) }}"
                        class="btn btn-outline-primary px-4 rounded-pill">
                        Masuk
                    </a>
                @endguest
                @auth
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="btn btn-outline-danger px-4 rounded-pill">
                            Keluar
                        </button>
                    </form>
                @endauth
            </div>
        </div>
    </div>
</nav>
