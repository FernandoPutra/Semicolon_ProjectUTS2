@extends('layouts.main')

@section('contents')
    <section id="hero" class="container">
        <div id="hero-carousel" class="carousel carousel-dark slide">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#hero-carousel" data-bs-slide-to="0" class="active" aria-current="true"
                    aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#hero-carousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#hero-carousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="p-5">
                        <div class="container-fluid py-5 text-center">
                            <h1 class="display-5 fw-bold text-primary">
                                Temukan Keseimbangan Emosionalmu - Stress Test Level dari Semicolon!
                            </h1>
                            <p class="col-md-8 mx-auto">
                                Stress Test Level: Tes kesehatan mentalmu dan temukan cara untuk mencapai keseimbangan
                                emosional yang sejati. Jaga kesehatan mentalmu dengan Semicolon!
                            </p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="p-5">
                        <div class="container-fluid py-5 text-center">
                            <h1 class="display-5 fw-bold text-primary">Menembus Batas, Menguji Kesehatan Mentalmu dengan
                                Stress Test Level!</h1>
                            <p class="col-md-8 mx-auto">
                                Hadapi ujian stres terdepan yang akan membantu kamu mengenali dan mengelola kesehatan
                                mentalmu.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="p-5">
                        <div class="container-fluid py-5 text-center">
                            <h1 class="display-5 fw-bold text-primary">Raih Kesehatan Mental Optimal</h1>
                            <p class="col-md-8 mx-auto">
                                angan biarkan stres mengendalikan hidupmu. Uji kemampuanmu dengan Stress Test Level dari
                                Semicolon dan temukan strategi baru untuk meraih kesehatan mental optimal.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="p-5">
                        <div class="container-fluid py-5 text-center">
                            <h1 class="display-5 fw-bold text-primary">Membuka Pintu Menuju Kesehatan Mental yang Lebih Baik
                            </h1>
                            <p class="col-md-8 mx-auto">
                                Sadari pentingnya kesehatan mental dan pelajari cara menghadapinya. Stress Test Level dari
                                Semicolon akan membantumu memperkuat kesehatan mentalmu dan mencapai kehidupan yang lebih
                                seimbang.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#hero-carousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#hero-carousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
@endsection

@push('add-js')
    <script type="text/javascript">
        const myCarouselElement = document.querySelector("#hero-carousel");

        const carousel = new bootstrap.Carousel(myCarouselElement, {
            ride: "carousel",
            interval: 3000,
            touch: false,
        });
    </script>
@endpush
