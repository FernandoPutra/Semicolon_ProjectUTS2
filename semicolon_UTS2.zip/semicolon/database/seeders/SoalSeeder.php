<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SoalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('soal')->insert([
            ['isi_soal' => 'Menjadi marah karena hal-hal kecil/sepele', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Mulut terasa kering', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Tidak dapat melihat hal yang positif dari suatu kejadian', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasakan gangguan dalam bernapas (napas cepat, sulit bernapas)', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa sepertinya tidak kuat lagi untuk melakukan suatu kegiatan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Cenderung bereaksi berlebihan pada situasi', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Kelemahan pada anggota tubuh', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Kesulitan untuk relaksasi/bersantai', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Cemas yang berlebihan dalam suatu situasi namun bisa lega jika hal/situasi itu berakhir', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Pesimis', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Mudah merasa kesal', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa banyak menghabiskan energi karena cemas', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa sedih dan depresi', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Tidak sabaran', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Kelelahan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Kehilangan minat pada banyak hal (misal: makan, ambulasi, sosialisasi)', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa diri tidak layak', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Mudah tersinggung', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Berkeringat (misal: tangan berkeringat) tanpa stimulasi oleh cuaca maupun latihan fisik', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Ketakutan tanpa alasan yang jelas', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa hidup tidak berharga', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Sulit untuk beristirahat', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Kesulitan dalam menelan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Tidak dapat menikmati hal-hal yang saya lakukan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Perubahan kegiatan jantung dan denyut nadi tanpa stimulasi oleh latihan fisik', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa hilang harapan dan putus asa', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Mudah marah', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Mudah panik', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Kesulitan untuk tenang setelah sesuatu yang mengganggu', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Takut diri terhambat oleh tugas-tugas yang tidak biasa dilakukan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Sulit untuk antusias pada banyak hal', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Sulit mentoleransi gangguan-gangguan terhadap hal yang sedang dilakukan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Berada pada keadaan tegang', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa tidak berharga', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Tidak dapat memaklumi hal apapun yang menghalangi anda untuk menyelesaikan hal yang sedang Anda lakukan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Ketakutan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Tidak ada harapan untuk masa depan', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Merasa hidup tidak berarti', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Mudah gelisah', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Khawatir dengan situasi saat diri Anda mungkin menjadi panik dan mempermalukan diri sendiri', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Gemetar', 'jenis_tes' => 'stress test level'],
            ['isi_soal' => 'Sulit untuk meningkatkan inisiatif dalam melakukansesuatu', 'jenis_tes' => 'stress test level'],
        ]);
    }
}
